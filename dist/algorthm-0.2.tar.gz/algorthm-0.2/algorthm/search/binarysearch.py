class Binarysearch:
    def __init__(self):
        self.input=[1,2,3]
    def print_data(self,input):
        for i in range(len(input)):
            print(input[i])