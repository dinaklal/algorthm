from algorthm.search.binarysearch import Binarysearch
from algorthm.search.linearsearch import Linearsearch
