
import sys


sys.path.append('../algorthm')

from algorthm.sort.bubbleSort import bubbleSort
from algorthm.sort.insertionSort import insertionSort
from algorthm.sort.mergeSort import mergeSort
from algorthm.sort.shellSort import shellSort
from algorthm.sort.selectionSort import selectionSort
        

# arr = os.listdir()

# for item in arr :
#    if item.endswith(".py") and item != "__init__.py":
#       code = "from algorthm.sort."+str(item[:-3])+" import "+str(item[:-3])
#      print (code)
#     exec(code)

        
