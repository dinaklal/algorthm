
# algorthm
A python package for visualizing and learning algorithms. 




## Authors

Dinak Lal V -[www.dinaklal.in]

dinaklal@gmail.com

## Usage


 * Install package - **pip install algorthm**
 
 * Import into your code - **import algorthm**
 * Use methods. Default case the algorithms in this package give you step wise result so that one
 can understand the back ground operations- **algorthm.sort.bubbleSort(list)**
 * For using  algorithms without stepwise result, pass "False" as last argument
 eg -: **algorthm.sort.bubbleSort(list,False)**
